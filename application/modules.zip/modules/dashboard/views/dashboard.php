<section class="content-header">
<h1>
<?php echo GROUPDESC ?>
<small><?php echo USER_NAME;?> </small>
</h1>
</section></br>
 
<section class="content-header">
	<div class="no-border">
                	    </div>
		
</section>