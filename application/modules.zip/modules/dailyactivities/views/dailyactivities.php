<section class="content-header">
<?php echo $title;?>
<ol class="breadcrumb">
</section>
<?php    	
	echo $content; 
		?>	
	