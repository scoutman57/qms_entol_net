<section class="content-header"><h1>Division<small>Division</small></h1><ol class="breadcrumb"></section>  </br>
<?php    	
	echo $content; 
		?>	
	