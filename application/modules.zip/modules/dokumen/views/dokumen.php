<section class="content-header"><h1>Images<small>Images</small></h1><ol class="breadcrumb"></section>  </br>
<?php    	
	echo $content; 
		?>	
	