<section class="content-header"><h1>Dokumen<small><?php echo GROUPDESC ?></small></h1><ol class="breadcrumb"></section>  </br>
<?php    	
	echo $content; 
		?>	
	